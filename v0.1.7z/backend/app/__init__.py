from flask import Flask, render_template
from .config import Config
from .extensions import db

def create_app():
    """Фабрика для создания экземпляра Flask приложения"""
    app = Flask(__name__, template_folder='templates')
    
    # Загрузка конфигурации
    app.config.from_object(Config)
    
    # Инициализация расширений
    db.init_app(app)
    
    # Регистрация blueprint'ов
    from .routes.main import main_bp
    app.register_blueprint(main_bp)
    
    # Создание таблиц БД
    with app.app_context():
        from .models.variety import Variety
        db.create_all()
    
    @app.errorhandler(500)
    def internal_error(error):
        return render_template('500.html'), 500

    return app