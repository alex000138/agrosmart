from flask_sqlalchemy import SQLAlchemy

# Инициализация расширений
db = SQLAlchemy()