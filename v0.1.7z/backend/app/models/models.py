from .extensions import db

class Variety(db.Model):
    __tablename__ = 'varieties'
    
    id = db.Column(db.Integer, primary_key=True)
    name_main = db.Column(db.String(100), nullable=False)
    type_main = db.Column(db.String(50))
    code = db.Column(db.String(20))
    description = db.Column(db.Text)
    origin = db.Column(db.String(100))
    registration_year = db.Column(db.Integer)
    
    def __repr__(self):
        return f'<Variety {self.name_main}>'