from .variety import Variety

__all__ = ['Variety']  # Явно указываем, что экспортируем