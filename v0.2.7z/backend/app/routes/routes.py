from backend.app.models import (
    Variety, 
    Disease,
    DiseaseResistance,
    Yield,
    Region,
    GrowingRegion
)